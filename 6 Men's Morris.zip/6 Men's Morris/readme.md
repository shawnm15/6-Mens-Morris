2AA4 Assignment

Need to do still:

-Validate a move (supported from below?)
-Display errors (wtf is considered an error though)
-???

Design Document

REWORKED PROJECT FILE